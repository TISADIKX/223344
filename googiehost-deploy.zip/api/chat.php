<?php
/**
 * BloopX Chat API Endpoint for GoogieHost / PHP Hosting
 */

// Allow CORS from any origin
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!isset($data['messages']) || !is_array($data['messages'])) {
    http_response_code(400);
    echo json_encode(["error" => "messages array is required"]);
    exit;
}

$apiKey = "sk-xt-00f5e006f6e7a60050887fbcf1be7b600c79d8daf3ff86fd";
$modelsToTry = [
    "qwen/qwen3.8-omni-flash:free",
    "qwen/qwen3.8-omni-flash",
    "qwen3.8-omni-flash",
    "mistralai/ministral-14b",
    "sensenova/sensenova-6.8-flash-lite",
    "mistralai/mistral-large-2512"
];

$normalizedMessages = [];
$normalizedMessages[] = [
    "role" => "system",
    "content" => "You are BloopX AI. Be concise, direct, helpful, and clear. Do not state or mention what model or company you are powered by. Avoid verbose pleasantries or unnecessary markdown fluff."
];

foreach ($data['messages'] as $m) {
    $content = isset($m['content']) ? trim((string)$m['content']) : '';
    if (!empty($content)) {
        $normalizedMessages[] = [
            "role" => isset($m['role']) ? $m['role'] : "user",
            "content" => $content
        ];
    }
}

// Keep last 8 messages
if (count($normalizedMessages) > 9) {
    $system = $normalizedMessages[0];
    $recent = array_slice($normalizedMessages, -8);
    $normalizedMessages = array_merge([$system], $recent);
}

$lastError = "Failed to communicate with AI chat model";

foreach ($modelsToTry as $model) {
    for ($attempt = 1; $attempt <= 2; $attempt++) {
        $payload = json_encode([
            "model" => $model,
            "messages" => $normalizedMessages,
            "max_tokens" => 800,
            "temperature" => 0.7
        ]);

        $ch = curl_init("https://api.xkiro.com/v1/chat/completions");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer " . $apiKey
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr = curl_error($ch);
        curl_close($ch);

        if ($response && $httpCode >= 200 && $httpCode < 300) {
            $resData = json_decode($response, true);
            $content = isset($resData['choices'][0]['message']['content']) ? trim($resData['choices'][0]['message']['content']) : '';
            if (!empty($content)) {
                $tokens = isset($resData['usage']['total_tokens']) ? (int)$resData['usage']['total_tokens'] : max(40, (int)(strlen($content) / 4));
                echo json_encode([
                    "content" => $content,
                    "tokensUsed" => $tokens,
                    "provider" => "BloopX"
                ]);
                exit;
            }
        } else {
            $lastError = $curlErr ? $curlErr : "HTTP " . $httpCode . " from " . $model;
        }

        if ($attempt < 2) {
            usleep(500000); // 500ms
        }
    }
}

http_response_code(500);
echo json_encode(["error" => "AI response failed: " . $lastError]);

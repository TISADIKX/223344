<?php
/**
 * BloopX Photo Generation API Endpoint for GoogieHost / PHP Hosting
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

$prompt = isset($data['prompt']) ? trim((string)$data['prompt']) : '';
if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(["error" => "prompt is required"]);
    exit;
}

$aspectRatio = isset($data['aspectRatio']) ? $data['aspectRatio'] : '1:1';
$quality = isset($data['quality']) ? $data['quality'] : 'hd';
$apiKey = "sk-xt-00f5e006f6e7a60050887fbcf1be7b600c79d8daf3ff86fd";

// Calculate exact pixel target dimensions
$targetWidth = 1080;
$targetHeight = 1080;
if ($quality === 'standard') {
    if ($aspectRatio === '16:9') { $targetWidth = 1024; $targetHeight = 576; }
    elseif ($aspectRatio === '9:16') { $targetWidth = 576; $targetHeight = 1024; }
    elseif ($aspectRatio === '4:3') { $targetWidth = 960; $targetHeight = 720; }
    elseif ($aspectRatio === '3:4') { $targetWidth = 720; $targetHeight = 960; }
    else { $targetWidth = 800; $targetHeight = 800; }
} elseif ($quality === 'ultra') {
    if ($aspectRatio === '16:9') { $targetWidth = 1920; $targetHeight = 1080; }
    elseif ($aspectRatio === '9:16') { $targetWidth = 1080; $targetHeight = 1920; }
    elseif ($aspectRatio === '4:3') { $targetWidth = 1600; $targetHeight = 1200; }
    elseif ($aspectRatio === '3:4') { $targetWidth = 1200; $targetHeight = 1600; }
    else { $targetWidth = 1600; $targetHeight = 1600; }
} else { // hd
    if ($aspectRatio === '16:9') { $targetWidth = 1280; $targetHeight = 720; }
    elseif ($aspectRatio === '9:16') { $targetWidth = 720; $targetHeight = 1280; }
    elseif ($aspectRatio === '4:3') { $targetWidth = 1280; $targetHeight = 960; }
    elseif ($aspectRatio === '3:4') { $targetWidth = 960; $targetHeight = 1280; }
    else { $targetWidth = 1080; $targetHeight = 1080; }
}

// Framing hint for aspect ratio
$framing = "balanced 1:1 square composition";
if ($aspectRatio === '16:9') $framing = "wide cinematic 16:9 horizontal landscape composition";
elseif ($aspectRatio === '9:16') $framing = "vertical portrait 9:16 mobile composition";
elseif ($aspectRatio === '4:3') $framing = "classic 4:3 horizontal photograph composition";
elseif ($aspectRatio === '3:4') $framing = "classic 3:4 vertical portrait photograph composition";

$enhancedPrompt = "Unedited RAW 35mm DSLR photograph of " . $prompt . ", " . $framing . ", authentic natural textures, realistic ambient lighting, sharp optical focus";

// Visual Realism Compiler
$compilerCh = curl_init("https://api.xkiro.com/v1/chat/completions");
curl_setopt($compilerCh, CURLOPT_RETURNTRANSFER, true);
curl_setopt($compilerCh, CURLOPT_POST, true);
curl_setopt($compilerCh, CURLOPT_POSTFIELDS, json_encode([
    "model" => "mistralai/ministral-14b",
    "messages" => [
        [
            "role" => "system",
            "content" => "You are BloopX Visual Realism Engine. Convert the user prompt into ONE concise English description (40-60 words) for an authentic unedited RAW 35mm DSLR photograph. Start with: Unedited RAW 35mm DSLR photograph of"
        ],
        ["role" => "user", "content" => $prompt]
    ],
    "max_tokens" => 80
]));
curl_setopt($compilerCh, CURLOPT_HTTPHEADER, ["Content-Type: application/json", "Authorization: Bearer " . $apiKey]);
curl_setopt($compilerCh, CURLOPT_TIMEOUT, 6);
curl_setopt($compilerCh, CURLOPT_SSL_VERIFYPEER, false);
$compilerRes = curl_exec($compilerCh);
curl_close($compilerCh);

if ($compilerRes) {
    $cData = json_decode($compilerRes, true);
    if (!empty($cData['choices'][0]['message']['content'])) {
        $cText = trim($cData['choices'][0]['message']['content']);
        if (strlen($cText) > 15) {
            $enhancedPrompt = $cText . ", " . $framing . ", authentic natural textures, realistic lighting";
        }
    }
}

// Helper to center-crop and resize image bytes to exact target aspect ratio and dimensions using PHP GD
function formatImageBytesToSettings($imageBytes, $targetW, $targetH, $qualityName) {
    if (!extension_loaded('gd') || !function_exists('imagecreatefromstring')) {
        return $imageBytes;
    }
    $src = @imagecreatefromstring($imageBytes);
    if (!$src) return $imageBytes;
    
    $srcW = imagesx($src);
    $srcH = imagesy($src);
    if ($srcW <= 0 || $srcH <= 0) {
        imagedestroy($src);
        return $imageBytes;
    }
    
    $srcAspect = $srcW / $srcH;
    $targetAspect = $targetW / $targetH;
    
    if ($srcAspect > $targetAspect) {
        $cropH = $srcH;
        $cropW = (int)round($srcH * $targetAspect);
        $cropX = (int)round(($srcW - $cropW) / 2);
        $cropY = 0;
    } else {
        $cropW = $srcW;
        $cropH = (int)round($srcW / $targetAspect);
        $cropX = 0;
        $cropY = (int)round(($srcH - $cropH) / 2);
    }
    
    $dst = imagecreatetruecolor($targetW, $targetH);
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    
    imagecopyresampled($dst, $src, 0, 0, $cropX, $cropY, $targetW, $targetH, $cropW, $cropH);
    
    ob_start();
    $jpegQ = ($qualityName === 'ultra') ? 95 : (($qualityName === 'hd') ? 90 : 82);
    imagejpeg($dst, null, $jpegQ);
    $outputBytes = ob_get_clean();
    
    imagedestroy($src);
    imagedestroy($dst);
    
    return $outputBytes ? $outputBytes : $imageBytes;
}

// 1. Tier 1: Subnp FLUX-schnell free API
$ch = curl_init("https://subnp.com/api/free/generate");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    "prompt" => $enhancedPrompt,
    "model" => "flux-schnell"
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_TIMEOUT, 18);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$subnpRes = curl_exec($ch);
$subnpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($subnpRes && $subnpCode >= 200 && $subnpCode < 300) {
    $subData = json_decode($subnpRes, true);
    if (!empty($subData['imageUrl'])) {
        $imgUrl = $subData['imageUrl'];
        // Download image to enforce exact aspect ratio via GD
        $imgCh = curl_init($imgUrl);
        curl_setopt($imgCh, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($imgCh, CURLOPT_TIMEOUT, 12);
        curl_setopt($imgCh, CURLOPT_SSL_VERIFYPEER, false);
        $rawImg = curl_exec($imgCh);
        curl_close($imgCh);

        if ($rawImg && strlen($rawImg) > 4000) {
            $formatted = formatImageBytesToSettings($rawImg, $targetWidth, $targetHeight, $quality);
            echo json_encode([
                "imageUrl" => "data:image/jpeg;base64," . base64_encode($formatted),
                "prompt" => $prompt,
                "aspectRatio" => $aspectRatio,
                "quality" => $quality,
                "provider" => "BloopX"
            ]);
            exit;
        }

        echo json_encode([
            "imageUrl" => $imgUrl,
            "prompt" => $prompt,
            "aspectRatio" => $aspectRatio,
            "quality" => $quality,
            "provider" => "BloopX"
        ]);
        exit;
    }
}

// 2. Tier 2: MagicStudio Direct DSLR Photo Engine
$formFields = [
    'prompt' => $enhancedPrompt,
    'output_format' => 'bytes',
    'user_profile_id' => 'null',
    'anonymous_user_id' => bin2hex(random_bytes(16)),
    'request_timestamp' => sprintf('%.3f', microtime(true)),
    'user_is_subscribed' => 'false',
    'client_id' => 'pSgX7WgjukXCBoYwDM8G8GLnRRkvAoJlqa5eAVvj95o'
];

$ch = curl_init("https://ai-api.magicstudio.com/api/ai-art-generator");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($formFields));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Origin: https://magicstudio.com",
    "Referer: https://magicstudio.com/ai-art-generator/"
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 18);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$magicRes = curl_exec($ch);
$magicCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($magicRes && $magicCode === 200 && strlen($magicRes) > 8000) {
    $formatted = formatImageBytesToSettings($magicRes, $targetWidth, $targetHeight, $quality);
    $b64 = base64_encode($formatted);
    echo json_encode([
        "imageUrl" => "data:image/jpeg;base64," . $b64,
        "prompt" => $prompt,
        "aspectRatio" => $aspectRatio,
        "quality" => $quality,
        "provider" => "BloopX"
    ]);
    exit;
}

// 3. Tier 3: Xkiro Image Generation API
$xkiroSize = ($aspectRatio === '16:9') ? "1792x1024" : (($aspectRatio === '9:16') ? "1024x1792" : "1024x1024");
$ch = curl_init("https://api.xkiro.com/v1/images/generations");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    "model" => "sensenova/sensenova-u1.5-lite",
    "prompt" => $enhancedPrompt,
    "size" => $xkiroSize
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer " . $apiKey
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$xkiroRes = curl_exec($ch);
$xkiroCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($xkiroRes && $xkiroCode >= 200 && $xkiroCode < 300) {
    $xData = json_decode($xkiroRes, true);
    if (!empty($xData['data'][0]['url'])) {
        echo json_encode([
            "imageUrl" => $xData['data'][0]['url'],
            "prompt" => $prompt,
            "aspectRatio" => $aspectRatio,
            "quality" => $quality,
            "provider" => "BloopX"
        ]);
        exit;
    }
    if (!empty($xData['data'][0]['b64_json'])) {
        $rawBytes = base64_decode($xData['data'][0]['b64_json']);
        $formatted = formatImageBytesToSettings($rawBytes, $targetWidth, $targetHeight, $quality);
        echo json_encode([
            "imageUrl" => "data:image/jpeg;base64," . base64_encode($formatted),
            "prompt" => $prompt,
            "aspectRatio" => $aspectRatio,
            "quality" => $quality,
            "provider" => "BloopX"
        ]);
        exit;
    }
}

// If generation took longer, return safe JSON cooldown rather than fatal 500
echo json_encode([
    "imageUrl" => null,
    "cooldown" => true
]);

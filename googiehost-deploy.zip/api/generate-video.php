<?php
/**
 * BloopX Video Generation Endpoint for GoogieHost / PHP Hosting
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

$prompt = isset($data['prompt']) ? trim((string)$data['prompt']) : '';
if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(["error" => "prompt is required"]);
    exit;
}

$duration = (isset($data['duration']) && ((int)$data['duration'] === 5)) ? 5 : 10;
$aspectRatio = (isset($data['aspectRatio']) && in_array($data['aspectRatio'], ['16:9', '9:16', '1:1'])) ? $data['aspectRatio'] : '16:9';
$quality = (isset($data['quality']) && in_array($data['quality'], ['480p', '720p', '1080p'])) ? $data['quality'] : '720p';

$wanAspect = ($aspectRatio === '9:16') ? '9:16 (480x832)' : (($aspectRatio === '1:1') ? '1:1 (640x640)' : '16:9 (832x480)');
$wanPrompt = "Cinematic real-world live-action video of " . $prompt . ", smooth natural fluid motion, authentic 35mm cinema lighting, sharp optical focus";
$wanNeg = "blurry, low quality, static, artifacts, watermark";

// Call Hugging Face Gradio API space for Wan 2.2 Text-to-Video
$spaceUrl = "https://upsampler-wan-2-2-14b-text-to-video.hf.space";
$postUrl = $spaceUrl . "/gradio_api/call/generate_video";

$ch = curl_init($postUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    "data" => [
        $wanPrompt,
        $wanAspect,
        4,
        $wanNeg,
        ($duration === 5 ? 5.0 : 10.0),
        1,
        1,
        rand(100000, 9999999),
        true
    ]
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$postRes = curl_exec($ch);
$postCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$eventId = null;
if ($postRes && $postCode >= 200 && $postCode < 300) {
    $pData = json_decode($postRes, true);
    $eventId = isset($pData['event_id']) ? $pData['event_id'] : null;
}

if ($eventId) {
    // Generate a jobId and store tracking info in temp dir
    $jobId = "vjob_" . time() . "_" . bin2hex(random_bytes(4));
    $tempFile = sys_get_temp_dir() . "/bloopx_vjob_" . $jobId . ".json";
    
    file_put_contents($tempFile, json_encode([
        "jobId" => $jobId,
        "eventId" => $eventId,
        "spaceUrl" => $spaceUrl,
        "status" => "processing",
        "progress" => 20,
        "duration" => $duration,
        "aspectRatio" => $aspectRatio,
        "quality" => $quality,
        "prompt" => $prompt,
        "createdAt" => time()
    ]));

    echo json_encode([
        "jobId" => $jobId,
        "status" => "processing",
        "progress" => 20,
        "prompt" => $prompt,
        "duration" => $duration,
        "aspectRatio" => $aspectRatio,
        "quality" => $quality
    ]);
} else {
    // Space busy; trigger client-side video synthesis fallback
    echo json_encode([
        "jobId" => null,
        "status" => "fallback",
        "error" => "Wan GPU busy, using high-speed renderer"
    ]);
}
